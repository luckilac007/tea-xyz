from setuptools import setup

setup(
    author='luckilac',
    author_email='luckilac007@gmail.com',
    name='tea-xyz-lucki',
    version='1.0.6',
    description='A simple package for https://app.tea.xyz/. Example tea-xyz - https://github.com/luckilac007/tea-xyz',
    url='https://github.com/luckilac007/tea-xyz',
    project_urls={
        'Homepage': 'https://github.com/luckilac007/tea-xyz',
        'Source': 'https://github.com/luckilac007/tea-xyz',
    },
    py_modules=['hello_tea'],
    entry_points={
        'console_scripts': [
            'hello-tea=hello_tea:hello_tea_func'
        ]
    },
    classifiers=[
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
    ],
    python_requires='>=3.6',
    install_requires=[
        'requests>=2.20.0',
        'tea-xyz-lucki',
    ],
)
